Ⅰ.Problem statement
Design a machine learning model to predict enterprise profits, based on BYD's cost and sales data for the first 8 months, to achieve the following goals:
①　Data preprocessing (cleaning, normalization, feature selection).
②　Build a profit calculation module to achieve monthly profit queries.
③　Use decision tree regression model to predict September profits, and visually analyze profit trends and composition.

Ⅱ.Key findings
①　Data cleaning: Filter for null values and significant outliers (such as negative sales and selling prices)
②　Normalization: I tried minimum maximum normalization and Z-score normalization, and compared them before choosing the former;
③　Feature selection: Correlation analysis (threshold 0.3) selects features strongly correlated with profit: revenue (significantly positively correlated with correlation coefficient), procurement cost (negatively correlated), electricity cost (negatively correlated), and fixed cost is excluded due to low correlation.

Ⅲ.Model performance:
Model performance: MSE and RMSE measure errors, R ² evaluates goodness of fit, divides training and testing sets, and trains decision tree regression models.

Ⅳ.Potential improvement directions
①　Data level: Supplement more vehicle model data, reduce estimation dependence, and introduce external variables such as market share and promotional activities.
②　Feature engineering: Cross validation of feature importance using algorithms such as Recursive Feature Elimination (RFE) or Random Forest.
③　Model optimization: Adjust decision tree parameters or introduce time series analysis (such as ARIMA) to capture profit trends and improve the accuracy of time series forecasting.
