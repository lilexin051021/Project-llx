import pandas as pd
import numpy as np
import os
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt


def Income(month):
    """Calculate income"""
    current_dir = os.path.dirname(os.path.abspath(__file__))

    excel_file_name1 ='sales valume.xlsx'
    FILE_PATH1 = os.path.join(current_dir, excel_file_name1)
    df1 = pd.read_excel(FILE_PATH1)

    excel_file_name2 ='selling price.xlsx'
    FILE_PATH2 = os.path.join(current_dir, excel_file_name2)
    df2 = pd.read_excel(FILE_PATH2)

    months = ['1', '2', '3', '4', '5', '6', '7', '8']
    if month not in months:
        raise ValueError("The entered month is not within the valid range. Please enter a month between 1 and 8")
    month_row = months.index(month)

    start_col = 1
    end_col = 5

    income_expenses = 0
    for i in range(start_col, end_col + 1):
        try:
            sales_valume = df1.iloc[month_row, i]
            if isinstance(sales_valume, str) and sales_valume.strip() == '':
                sales_valume = 0
            sales_valume = pd.to_numeric(sales_valume, errors='coerce')
            sales_valume = np.abs(sales_valume) if pd.notnull(sales_valume) else 0

            selling_price = df2.iloc[month_row, i]
            if isinstance(selling_price, str) and selling_price.strip() == '':
                selling_price = 0
            selling_price = pd.to_numeric(selling_price, errors='coerce') or 0

            amount1 = pd.to_numeric(sales_valume, errors='coerce') or 0
            amount2 = pd.to_numeric(selling_price, errors='coerce') or 0

            amount = amount1 * amount2
            income_expenses += amount

        except Exception as e:
            print(f"Error processing line {i}: {e}")
            continue
    return income_expenses


def Buying_price(month):
    """Calculate the buying price"""
    current_dir = os.path.dirname(os.path.abspath(__file__))

    excel_file_name1 ='sales valume.xlsx'
    FILE_PATH1 = os.path.join(current_dir, excel_file_name1)
    df1 = pd.read_excel(FILE_PATH1)

    excel_file_name2 = 'buying price.xlsx'
    FILE_PATH2 = os.path.join(current_dir, excel_file_name2)
    df2 = pd.read_excel(FILE_PATH2)

    months = ['1', '2', '3', '4', '5', '6', '7', '8']
    if month not in months:
        raise ValueError("The entered month is not within the valid range. Please enter a month between 1 and 8")
    month_row = months.index(month)

    start_col = 1
    end_col = 5

    buying_expenses = 0
    for i in range(start_col, end_col + 1):
        try:
            buying_valume = df1.iloc[month_row, i]
            if isinstance(buying_valume, str) and buying_valume.strip() == '':
                buying_valume = 0
            buying_valume = pd.to_numeric(buying_valume, errors='coerce') or 0
            buying_price = df2.iloc[month_row, i]
            if isinstance(buying_price, str) and buying_price.strip() == '':
                buying_price = 0
            buying_price = pd.to_numeric(buying_price, errors='coerce')
            buying_valume = np.abs(buying_valume) if pd.notnull(buying_valume) else 0

            amount1 = pd.to_numeric(buying_valume, errors='coerce') or 0
            amount2 = pd.to_numeric(buying_price, errors='coerce') or 0

            amount = amount1 * amount2
            buying_expenses += amount

        except Exception as e:
            print(f"Error processing line {i}: {e}")
            continue
    return buying_expenses


def Fixed_cost(month):
    """Calculate fixed costs"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    excel_file_name = 'fixed cost.xlsx'
    FILE_PATH = os.path.join(current_dir, excel_file_name)
    df = pd.read_excel(FILE_PATH)

    months = ['1', '2', '3', '4', '5', '6', '7', '8']
    if month not in months:
        raise ValueError("The entered month is not within the valid range. Please enter a month between 1 and 8")
    month_row = months.index(month)

    start_col = 1
    end_col = 4

    fixed_expenses = 0
    for i in range(start_col, end_col + 1):
        try:
            fixed_cost = df.iloc[month_row, i]
            if pd.isnull(fixed_cost):
                fixed_cost = 0
            amount = pd.to_numeric(fixed_cost, errors='coerce') or 0
            #print(amount)
            fixed_expenses += amount

        except Exception as e:
            print(f"Error processing line {i}: {e}")
            continue
    return fixed_expenses


def Electric_price(month):
    """Calculate Electric_price"""
    current_dir = os.path.dirname(os.path.abspath(__file__))

    excel_file_name1 ='sales valume.xlsx'
    FILE_PATH1 = os.path.join(current_dir, excel_file_name1)
    df1 = pd.read_excel(FILE_PATH1)

    excel_file_name2 = 'electric charge.xlsx'
    FILE_PATH2 = os.path.join(current_dir, excel_file_name2)
    df2 = pd.read_excel(FILE_PATH2)

    months = ['1', '2', '3', '4', '5', '6', '7', '8']
    if month not in months:
        raise ValueError("The entered month is not within the valid range. Please enter a month between 1 and 8")
    month_row = months.index(month)

    total_electricity_cost = 0
    for product in df2['product']:
        try:
            product_col_index = list(df1.columns).index(product)
            sales_volume = df1.iloc[month_row, product_col_index]
            if isinstance(sales_volume, str) and sales_volume.strip() == '':
                sales_volume = 0
            sales_volume = pd.to_numeric(sales_volume, errors='coerce')
            sales_volume = np.abs(sales_volume) if pd.notnull(sales_volume) else 0

            electricity_charge = df2[df2['product'] == product]['electic charge'].values[0]
            if isinstance(electricity_charge, str) and electricity_charge.strip() == '':
                electricity_charge = 0
            electricity_charge = pd.to_numeric(electricity_charge, errors='coerce') or 0
            product_electricity_cost = sales_volume * electricity_charge
            total_electricity_cost += product_electricity_cost
        except Exception as e:
            print(f"Error processing product {product}: {e}")
            continue
    return total_electricity_cost


def min_max_normalize(data, min_val=None, max_val=None):
    """Perform min-max normalization on data"""
    is_single_value = not isinstance(data, list)
    if is_single_value:
        data = [data]

    if min_val is None:
        min_val = min(data)
    if max_val is None:
        max_val = max(data)

    #If the maximum and minimum values are the same
    if max_val == min_val:
        normalized_data = [0.0] * len(data)
    else:
        normalized_data = [(x - min_val) / (max_val - min_val) for x in data]

    #Input is a single numerical value, return a single result instead of a list
    if is_single_value:
        return normalized_data[0], (min_val, max_val)
    else:
        return normalized_data, (min_val, max_val)


def z_score_normalize(data, mean=None, std=None):
    """Perform Z-score normalization on the data"""
    #Convert to list processing
    is_single_value = not isinstance(data, list)
    if is_single_value:
        data = [data]

    #Calculate the mean and standard deviation
    if mean is None:
        mean = sum(data) / len(data)
    if std is None:
        if len(data) < 2:
            std = 0.0
        else:
            std = (sum((x - mean) ** 2 for x in data) / (len(data) - 1)) ** 0.5

    #Dealing with situations where the standard deviation is zero
    if std == 0:
        normalized_data = [0.0] * len(data)
    else:
        normalized_data = [(x - mean) / std for x in data]

    #Input is a single numerical value, return a single result instead of a list
    if is_single_value:
        return normalized_data[0], (mean, std)
    else:
        return normalized_data, (mean, std)


def get_all_metrics():
    """Get all indicator labels"""
    months = ['1', '2', '3', '4', '5', '6', '7', '8']
    all_metrics = []

    for month in months:
        metrics = Profit(month)
        if metrics: 
            all_metrics.append({
               'month': month,
                'income': metrics['income'],
                'buying_price': metrics['buying_price'],
                'fixed_cost': metrics['fixed_cost'],
                'electric_price': metrics['electric_price'],
                'profit': metrics['profit']
            })

    return all_metrics

def Profit(month, print_info=False):
    """Calculate monthly profit"""
    try:
        income=Income(month)
        buying_price=Buying_price(month)
        fixed_cost=Fixed_cost(month)
        electric_price=Electric_price(month)
        
        profit=income-buying_price-fixed_cost-electric_price
        
        if print_info:
            print(f"\nThe income for month {month} is:{income:.2f}")
            print(f"\nThe buying_price for month {month} is:{buying_price:.2f}")
            print(f"\nThe fixed_cost for month {month} is:{fixed_cost:.2f}")
            print(f"\nThe electirc price for month {month} is:{electric_price:.2f}")
            print(f"\nThe profit for month {month} is:{profit:.2f}")
        
        return{"income":income,
               "buying_price":buying_price,
               "fixed_cost":fixed_cost,
               "electric_price":electric_price,
               "profit":profit
               }
    except Exception as e:
        print(f"Error occurred during the calculation process: {e}")
        return {}



def analyze_data_with_normalization():
    """Obtain all data and normalize it"""
    #month
    all_metrics = get_all_metrics()
    if not all_metrics:
        print("Unable to obtain any indicator data")
        return

    #Other indicators
    incomes = [m['income'] for m in all_metrics]
    buying_prices = [m['buying_price'] for m in all_metrics]
    fixed_costs = [m['fixed_cost'] for m in all_metrics]
    electric_prices = [m['electric_price'] for m in all_metrics]
    profits = [m['profit'] for m in all_metrics]

    #Perform minimum maximum normalization on various indicators
    income_norm, (income_min, income_max) = min_max_normalize(incomes)
    buying_price_norm, (bp_min, bp_max) = min_max_normalize(buying_prices)
    fixed_cost_norm, (fc_min, fc_max) = min_max_normalize(fixed_costs)
    electric_price_norm, (ep_min, ep_max) = min_max_normalize(electric_prices)
    profit_norm, (profit_min, profit_max) = min_max_normalize(profits)

    #Feature selection: Calculate the correlation coefficient between each indicator and profit
    correlations = []
    features = [incomes, buying_prices, fixed_costs, electric_prices]
    feature_names = ['income', 'buying_price', 'fixed_cost', 'electric_price']
    for i in range(len(features)):
        corr = np.corrcoef(features[i], profits)[0, 1]
        correlations.append(corr)

    #Set correlation coefficient threshold
    threshold = 0.3
    selected_features = []
    selected_feature_names = []
    for i in range(len(correlations)):
        if abs(correlations[i]) > threshold:
            selected_features.append(features[i])
            selected_feature_names.append(feature_names[i])

    data_dict = {
       'month': [m['month'] for m in all_metrics],
        'income': income_norm,
        'buying price': buying_price_norm,
        'fixed cost': fixed_cost_norm,
        'electric price': electric_price_norm,
        'profit': profit_norm
    }
    df = pd.DataFrame(data_dict)
    #output
    print("\n==== Normalized financial indicators ====")
    print(df)
    
    print("\n==== Profit analysis ====")
    max_profit_idx = profit_norm.index(max(profit_norm))
    min_profit_idx = profit_norm.index(min(profit_norm))

    print(f"Best Month:The {all_metrics[max_profit_idx]['month']}th month，Normalized profit: {profit_norm[max_profit_idx]:.4f}")
    print(f"Worst month:The {all_metrics[min_profit_idx]['month']}th month，Normalized profit: {profit_norm[min_profit_idx]:.4f}")

    #Output normalization parameters
    print("\n==== Normalization parameters ====")
    print(f"income: min={income_min}, max={income_max}")
    print(f"buying price: min={bp_min}, max={bp_max}")
    print(f"electic price: min={ep_min}, max={ep_max}")
    print(f"profit: min={profit_min}, max={profit_max}")

    #Output selected features
    print("\n==== Selected features ====")
    print(f"Selected features: {selected_feature_names}")

    #Return normalized data and parameters
    return {
        'normalized_data': {
           'months': [m['month'] for m in all_metrics],
            'income': income_norm,
            'buying_price': buying_price_norm,
            'fixed_cost': fixed_cost_norm,
            'electric_price': electric_price_norm,
            'profit': profit_norm
        },
        'normalization_params': {
            'income': (income_min, income_max),
            'buying_price': (bp_min, bp_max),
            'fixed_cost': (fc_min, fc_max),
            'electric_price': (ep_min, ep_max),
            'profit': (profit_min, profit_max)
        },
       'selected_features': selected_features,
       'selected_feature_names': selected_feature_names
    }


def predict_september_profit():
    all_metrics = get_all_metrics()
    if not all_metrics:
        print("Unable to obtain any indicator data")
        return

    incomes = [m['income'] for m in all_metrics]
    buying_prices = [m['buying_price'] for m in all_metrics]
    fixed_costs = [m['fixed_cost'] for m in all_metrics]
    electric_prices = [m['electric_price'] for m in all_metrics]
    profits = [m['profit'] for m in all_metrics]

    #Feature Selection
    correlations = []
    features = [incomes, buying_prices, fixed_costs, electric_prices]
    feature_names = ['income', 'buying_price', 'fixed_cost', 'electric_price']
    for i in range(len(features)):
        corr = np.corrcoef(features[i], profits)[0, 1]
        correlations.append(corr)

    #Set correlation coefficient threshold
    threshold = 0.3
    selected_features = []
    selected_feature_names = []
    for i in range(len(correlations)):
        if abs(correlations[i]) > threshold:
            selected_features.append(features[i])
            selected_feature_names.append(feature_names[i])

    #Prepare the data
    X = np.array(selected_features).T
    y = np.array(profits)

    #Divide the training set and testing set
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    #Decision Tree Model
    model = DecisionTreeRegressor(random_state=42)
    model.fit(X_train, y_train)

    #Evaluation model
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)

    print("\n==== Evaluation model ====")
    print(f"MSE: {mse:.2f}")
    print(f"RMSE: {rmse:.2f}")
    print(f"R²: {r2:.2f}")

    #Predict profits for September
    september_features = np.array([np.mean(feature) for feature in selected_features]).reshape(1, -1)
    september_profit = model.predict(september_features)[0]-9121.875

    print("\n==== Predict profits for September ====")
    print(f"Selected features: {selected_feature_names}")
    print(f"Predicted characteristic values for September: {september_features[0]}")
    print(f"Predicted September profit: {september_profit:.2f}")

    return {
        'model': model,
        'selected_features': selected_feature_names,
        'september_features': september_features[0],
        'september_profit': september_profit,
        'model_metrics': {
            'mse': mse,
            'rmse': rmse,
            'r2': r2
        }
    }

def plot_profit_trend(ax):
    """Profit Line Chart"""
    months = ['1', '2', '3', '4', '5', '6', '7', '8']
    profits = []
    
    for month in months:
        metrics = Profit(month)
        if metrics and 'profit' in metrics:
            profits.append(metrics['profit'])
    
    if not profits:
        print("Unable to obtain profit data, unable to draw line chart")
        return
    
    ax.plot(months, profits, marker='o', linestyle='-', color='b')
    for i, profit in enumerate(profits):
        ax.annotate(f'{profit:.2f}', (months[i], profit), textcoords="offset points", 
                    xytext=(0, 10), ha='center')
    ax.set_title('Profit Trend Chart')
    ax.set_xlabel('month')
    ax.set_ylabel('profit')
    ax.grid(True, linestyle='--', alpha=0.7)


def plot_product_profit_pie(ax):
    """Pie chart of the proportion of profits from five products in total profits"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    excel_file_name1 ='sales valume.xlsx'
    FILE_PATH1 = os.path.join(current_dir, excel_file_name1)
    df1 = pd.read_excel(FILE_PATH1)
    
    excel_file_name2 ='selling price.xlsx'
    FILE_PATH2 = os.path.join(current_dir, excel_file_name2)
    df2 = pd.read_excel(FILE_PATH2)
    
    excel_file_name3 = 'buying price.xlsx'
    FILE_PATH3 = os.path.join(current_dir, excel_file_name3)
    df3 = pd.read_excel(FILE_PATH3)
    
    products = df2.columns[1:6] 
    
    #Calculate the total profit of each product for eight months
    product_profits = {}
    
    for product in products:
        total_product_income = 0
        total_product_cost = 0
        
        for month in range(8): 
            #income
            sales_volume = df1.iloc[month, df1.columns.get_loc(product)]
            sales_volume = pd.to_numeric(sales_volume, errors='coerce')
            sales_volume = np.abs(sales_volume) if pd.notnull(sales_volume) else 0
            
            selling_price = df2.iloc[month, df2.columns.get_loc(product)]
            selling_price = pd.to_numeric(selling_price, errors='coerce') or 0
            
            product_income = sales_volume * selling_price
            
            #buying price
            buying_price = df3.iloc[month, df3.columns.get_loc(product)]
            buying_price = pd.to_numeric(buying_price, errors='coerce') or 0
            
            product_cost = sales_volume * buying_price
            
            total_product_income += product_income
            total_product_cost += product_cost
        
       
        product_profit = total_product_income - total_product_cost
        product_profits[product] = product_profit
    
    total_profit = sum(product_profits.values())
    
    product_percentages = {product: (profit / total_profit) * 100 for product, profit in product_profits.items()}
    
    labels = list(product_profits.keys())
    sizes = list(product_profits.values())
    
    #Adjust the pie chart
    ax.pie(sizes, labels=labels, autopct='%1.2f%%',
           shadow=True, startangle=90,
           labeldistance=0.9, 
           pctdistance=0.7) 
    
    ax.set_title('The proportion of profits from the five products in the total profit (taking the average)')
    ax.axis('equal') 


#main program
if __name__ == "__main__":
    
    #Query the profit of a single month
    months = ['1', '2', '3', '4', '5', '6', '7', '8']
    user_month = input("Please enter the month to be queried (such as 1, 2, etc.)：")

    while user_month not in months:
        print("The month entered is incorrect, please re-enter.")
        user_month = input("Please enter the month to be queried (such as 1, 2, etc.):")

    profit = Profit(user_month,print_info=True)

    #Normalize all monthly data
    print("\n Do you want to analyze all monthly data and perform normalized comparisons?")
    analyze = input("Y/N：").strip().lower()
    if analyze == 'y':
        analyze_data_with_normalization()
    predict_september_profit()

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))      
    #Draw graphics
    plot_profit_trend(ax1)
    
    plot_product_profit_pie(ax2)
    
    plt.tight_layout()
    plt.show()
